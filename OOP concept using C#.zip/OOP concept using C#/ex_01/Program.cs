﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex_01
{
    class Program
    {
        static void Main(string[] args)
        {
            MotorCycleInfo();
            Console.ReadKey();
        }
        private static void MotorCycleInfo()
        {
            Console.Write("Model No\t:");
            string modelNo = Console.ReadLine();

            Console.Write("Make Year\t:");
            int makeYear = int.Parse(Console.ReadLine());

            Console.Write("No Of Gear\t:");
            int noOfGear = int.Parse(Console.ReadLine());

            Console.Write("Engine Capacity In CC\t:");
            int engineCapacityInCC = int.Parse(Console.ReadLine());

            Console.Write("Max Power\t:");
            int maxPower = int.Parse(Console.ReadLine());

            Console.Write("Max Tourque\t:");
            int maxTourque = int.Parse(Console.ReadLine());

            Console.Write("Cooling\t:");
            string cooling = Console.ReadLine();

            Console.Write("Front Brake\t:");
            string frontBrake = Console.ReadLine();

            Console.Write("Rear Brake\t:");
            string rearBrake = Console.ReadLine();

            Console.Write("Mileage\t:");
            double mileage = double.Parse(Console.ReadLine());

            Console.Write("Starting Method\t:");
            string startingMethod = Console.ReadLine();

            MotorCycle m = new MotorCycle(modelNo, makeYear, noOfGear, engineCapacityInCC, maxPower, maxTourque, cooling, frontBrake, rearBrake, mileage, startingMethod);

            string specification = "";

            while (specification.ToLower() != "ok")
            {
                Console.Write("Add Exterior Design :[write ok to stop ]");
                specification = Console.ReadLine();
                if (specification.ToLower() != "ok")
                {
                    m.AddSpecification(specification);
                }
            }

            Console.WriteLine();
            Console.WriteLine("************************************************");
            Console.WriteLine();

            Console.WriteLine($"Model No\t\t: {m.ModelNo}");
            Console.WriteLine($"Year Make\t\t: {m.YearMake}");
            Console.WriteLine($"No of Gear\t\t: {m.NoOfGear}");
            Console.WriteLine($"Engine Capacity In CC\t\t: {m.EngineCapacityInCC}");
            Console.WriteLine($"Max Power\t\t: {m.MaxPower}");
            Console.WriteLine($"MaxTourque\t\t: {m.MaxTourque}");
            Console.WriteLine($"Cooling\t\t: {m.Cooling}");
            Console.WriteLine($"Front Brake\t\t: {m.FrontBrake}");
            Console.WriteLine($"Rear Brake\t\t: {m.RearBrake}");
            Console.WriteLine($"Mileage\t\t: {m.Mileage}");
            Console.WriteLine($"Starting Method\t\t: {m.StartingMethod}");
            Console.WriteLine($"Exterior Design\t\t: {m.ShowSpecification()}");
            Console.WriteLine($"Vehicle Type\t\t: {VehicleType.MotorCycle}");

        }
    }
}
