﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex_01
{
    public sealed class MotorCycle:TwoWheeler
    {
        public MotorCycle()//Default Constructor
        {
            
        }
        public MotorCycle(string modelNo,int yearMake,int noOfGear,int engineCapacityInCC,int maxPower,int maxTourque,string cooling,string frontBrake, string rearBrake, double mileage,string startingMethod)//Overloaded Constructor
        {
            this.ModelNo = modelNo;
            this.YearMake = yearMake;
            this.NoOfGear = noOfGear;
            this.EngineCapacityInCC = engineCapacityInCC;
            this.MaxPower = maxPower;
            this.MaxTourque = maxTourque;
            this.Cooling = cooling;
            this.FrontBrake = frontBrake;
            this.RearBrake = rearBrake;
            this.Mileage = mileage;
            this.StartingMethod = startingMethod;

        }
        public int MaxPower { get; set; }
        public int MaxTourque { get; set; }
        public string Cooling { get; set; }
        public string FrontBrake { get; set; }
        public string RearBrake { get; set; }
        public double Mileage { get; set; }
        public string StartingMethod { get; set; }

    }
}
