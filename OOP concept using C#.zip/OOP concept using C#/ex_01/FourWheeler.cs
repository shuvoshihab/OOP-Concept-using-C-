﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex_01
{
    public abstract class FourWheeler : Vehicle, IInteriorDesign
    {
        List<string> Specification = new List<string>();

        public void AddSpecification(string specification)
        {
            Specification.Add(specification);
        }

        public string ShowSpecification()
        {
            return string.Join(", ", Specification);
        }
    }
}
