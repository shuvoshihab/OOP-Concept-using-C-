﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex_01
{
    public sealed class Car:FourWheeler
    {
        public Car()
        {

        }
        public Car(string modelNo, int yearMake, int noOfGear, int engineCapacityInCC,int noOfSeat,int noOfDoor )
        {
            this.ModelNo = modelNo;
            this.YearMake = yearMake;
            this.NoOfGear = noOfGear;
            this.EngineCapacityInCC = engineCapacityInCC;
            this.NoOfSeat = noOfSeat;
            this.NoOfDoor = noOfDoor;

        }
        public int NoOfSeat { get; set; }
        public int NoOfDoor { get; set; }
    }
}
